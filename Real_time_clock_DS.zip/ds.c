        #include<stdio.h>
        #include<stdlib.h>
        #include<malloc.h>
        #include<string.h>

          struct gmt{
         char city[20];//declaration of structure of node
        int gmth;
        int gmm;
         };
         /////struct gmt x;
         typedef struct node{  //declaration of structure of node
        int timeh;
        int timm;

        int dist;
        char city[20];
        struct gmt e;
        struct node *link;
        }*NODE;



         int days,hours,minutes,timed,sumtime=0;//declaration of global variables used

         //creation of node
        NODE getnode()
        {
            NODE x;
            x=(NODE)malloc(20*(sizeof(NODE)));
            if(x==NULL){
                printf("out of memory");
            exit(0);
        }
        return x;
        }
         NODE insert(NODE start,int t,int d,int m,char c[])
        {
            NODE temp,cur;
            //char ct;

            temp=getnode();
            temp->timeh=t;
            temp->timm=m;
             // temp->e=x;


            FILE *fp1;
             fp1=fopen("gmt.txt","rb");


            while(1){
            //fread(&x,sizeof(x),1, fp1);
            fscanf(fp1,"%s%d%d",&temp->e.city,&temp->e.gmth,&temp->e.gmm);
            if(feof(fp1)){
                temp->e.gmth=0;
                temp->e.gmm=0;

                break;
            }
            if(strcmp(temp->e.city,c)==0)
            {

            printf("%s %d %d \n",temp->e.city,temp->e.gmth,temp->e.gmm);
            break;

            }
            }
            fclose(fp1);

            temp->dist =d;
            strcpy(temp->city,c);

            temp->link=NULL;
            if(start==NULL)
            return temp;
            cur=start;
            while(cur->link!=NULL)
            cur=cur->link;
            cur->link=temp;
            return start;
        }
         void time_of_day(int timh,int timm,int m,int h,int i){
        if(i<0)
        days=days-1;
        else if(i>0)
            days=days+1;


          days = (timh)/(24);

          if(days==0){
            printf("A day has not elapsed yet\n");

          }
          else {
            printf("%d days have elapsed since start of journey\n",days);

          }


            printf("The current time is %d:%d \n",h,m);




        }

        void difference_in_time(int timh,int timmm){

        if(timh>=24)
{


    printf("%d\t%d",timh%24,timmm);
}
else{

    printf("%d\t%d",timh,timmm);

}

        }


        //function to insert different parameters such as time,distance and name of city

        NODE display(NODE start)
        {
            NODE temp,prev,cur,in;
             FILE *fp1;
             char ct[100];


            int sumd=0;
            if(start==NULL){
         printf("list is empty");
         return start;

            }
           printf("Journey starts at 12 AM\n\n");
            printf("The traveller has a 24 hour clock\n\n");
                temp=start;
                in=start;
                int sumh,summ,x,y,count;
                  count=0;
                  sumtime=0;
                while(temp->link!=NULL){      //calculation of total time,total distance and city to city information takes place


                prev = temp;
                cur = temp->link;


                 x=(cur->timeh*60);
                 y=(cur->timm);
                sumtime = sumtime +x+y;

                sumh=sumtime/60;
                summ=sumtime%60;
                sumd = sumd + cur->dist;
               if((prev->timeh*60+prev->timm)>(cur->timeh*60+cur->timm))
                  count++;
                temp=temp->link;


                }
                if(cur==NULL){
                    printf("End of journey\n");
                    return start;
                }

                if(temp!=NULL){
                printf("Travelling from city %s to %s\n",prev->city,cur->city);
                printf("\n\n");
                int x=((cur->e.gmth*60+cur->e.gmm));
                int p=(prev->e.gmth*60+prev->e.gmm);

                int u=((cur->e.gmth*60+cur->e.gmm))-((prev->e.gmth*60+prev->e.gmm));

                printf("Total distance travelled  is %d kilometres\n",(sumd));
                int a=((cur->timeh*60+cur->timm)) -( (prev->timeh*60+prev->timm));

                int l=(60-(cur->timm-prev->timm))%60;
//int z=(cur->e.gmth*60+cur->e.gmm*60);




if(a>=0&&u<0&&(a+u)<0){
    int y=-u;

printf("Time difference between %s city and %s city is %d :%d\n",prev->city,cur->city,((a+y)/60)%24,(a+y)%60);

}
else if(a<0&&u<0&&(a+u)<0){
    int y=-u;
     printf("Time difference between %s city and %s city is %d :%d\n",prev->city,cur->city,(24+(a+y)/60)%24,(24*60+(a+y))%60);
}
else if(a<0&&u>0&&(a+u)<0)
     printf("Time difference between %s city and %s city is %d :%d\n",prev->city,cur->city,(24+(a+u)/60)%24,(24*60+(a+u))%60);

else
     printf("Time difference between %s city and %s city is %d :%d\n",prev->city,cur->city,((a+u)/60)%24,(a+u)%60);
int f=(in->e.gmth*60+in->e.gmm);
 int v=((cur->e.gmth*60+cur->e.gmm))-((in->e.gmth*60+in->e.gmm));
  int b=((cur->timeh*60+cur->timm)) -( (in->timeh*60+in->timm));
int ff=b+v;
if(b>=0&&v<0&&(b+v)<0){
    int f=-v;

printf("Time difference between %s city and %s city is %d :%d\n",prev->city,cur->city,((b+f)/60)%24,(b+f)%60);
    time_of_day((24*count+(b+v)/60),(24*count*60+(b+v))%60,cur->timm,cur->timeh,x);
}

else if(b<0&&v<0&&(b+v)<0){
    int f=-v;
                printf("Difference in time between %s city and %s city is %d: %d\n",in->city,cur->city,(24+(b+f)/60-1),(24*60+(v+f))%60);
                  time_of_day((24*count+(b+f)/60),(24*count*60+(b+f))%60,cur->timm,cur->timeh,x);

}
else if(b<0&&v>=0&&(b+v)<0){
    int f=-v;

                printf("Difference in time between %s city and %s city is %d: %d\n",in->city,cur->city,((b+v)/60-1),((b+v))%60);
                  time_of_day((24*count+(b+v)/60),(24*count*60+(b+v))%60,cur->timm,cur->timeh,x);

}
else{
 printf("Difference in time between %s city and %s city is %d: %d\n",in->city,cur->city,((b+v)/60),((b+v))%60);
                difference_in_time(cur->timeh,cur->timm);

                 time_of_day((24*count+(b+v)/60),(24*count*60+(b+v))%60,cur->timm,cur->timeh,x);
                }


                }
                else
                    printf("Happy journey\n");

        }



    //function to calculate number of days elapsed since journey and current time on watch

        //main function where inputs are taken and respective functions are called
        int main()
        {

           NODE start=NULL;
            int choice,ti,t,dis;
            char c[20];
            char ans;
            do{
            printf("\n1.insert\n2.display\n3.exit\n");
            printf("enter your choice\n");
            scanf("%d",&choice);
            switch(choice)
            {
                case 1:printf("Enter time\n");
                scanf("%d %d",&ti,&t);

                printf("Enter distance  travelled\n");
                scanf("%d",&dis);
                printf("Enter city name\n");
                scanf("%s",&c);
                start=insert(start,ti,dis,t,c);
                break;
                case 2:display(start);
                break;
                case 3:exit(0);
                break;
            }
            printf("do you want to continue\n");
            scanf("%s",&ans);
            }while(ans=='y'||ans=='Y');
        return 0;
        }


